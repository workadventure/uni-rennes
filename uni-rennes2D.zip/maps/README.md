# WorkAdventure Map Starter Kit - Maps Folder

In this directory you have to put all your maps created with Tiled, in JSON or TMJ format.

If you have map thumbnails you can put them here, and you can reference them in the `mapImage` property of each map.
We recommend using 500x500 images for the map thumbnails.